complied & tested on gcc 9.3.0-17ubuntu1~20.04

To complie run "make"

To run just a part use like "./A <N>" as example ./A 10 it gave output in "10" name file

To run just b part use like "./driver <file-name & file name should be N>" as example ./driver 4
it gave output as <algo_name>,<AWT>,<ATT>,<ART>

To test c part run "run.sh" it will run file with for N = 10,20,30,40,50, ten times for each value of N and print graph

My b part don't work on some process table , I am unable to find the mistake so because of that c part is not working.