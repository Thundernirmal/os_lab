#include <bits/stdc++.h>
using namespace std;

int FIFO(int pages[], int n, int frames);
int LRU(int pages[], int n, int frames);
int OPR(int pages[], int n, int frames);