echo "For string 7 0 1 2 0 3 0 4 2 3 0 3 2"
echo "and frames 3"
./memory 3 7 0 1 2 0 3 0 4 2 3 0 3 2
echo "and frames 4"
./memory 4 7 0 1 2 0 3 0 4 2 3 0 3 2
echo "and frames 5"
./memory 5 7 0 1 2 0 3 0 4 2 3 0 3 2
echo "and frames 6"
./memory 6 7 0 1 2 0 3 0 4 2 3 0 3 2
echo "For string 1 2 3 4 1 2 5 1 2 3 4 5"
echo "and frames 3"
./memory 3 1 2 3 4 1 2 5 1 2 3 4 5
echo "and frames 4"
./memory 4 1 2 3 4 1 2 5 1 2 3 4 5
echo "and frames 5"
./memory 5 1 2 3 4 1 2 5 1 2 3 4 5
echo "and frames 6"
./memory 6 1 2 3 4 1 2 5 1 2 3 4 5
echo "For string 3 1 2 5 0 6 4 1 2 3 5 1 0 2 3 6 5 3 6 2 3 6 4 5 2 7 1 2 3"
echo "and frames 3"
./memory 3 3 1 2 5 0 6 4 1 2 3 5 1 0 2 3 6 5 3 6 2 3 6 4 5 2 7 1 2 3
echo "and frames 4"
./memory 4 3 1 2 5 0 6 4 1 2 3 5 1 0 2 3 6 5 3 6 2 3 6 4 5 2 7 1 2 3
echo "and frames 5"
./memory 5 3 1 2 5 0 6 4 1 2 3 5 1 0 2 3 6 5 3 6 2 3 6 4 5 2 7 1 2 3
echo "and frames 6"
./memory 6 3 1 2 5 0 6 4 1 2 3 5 1 0 2 3 6 5 3 6 2 3 6 4 5 2 7 1 2 3
echo "For string 1 0 2 3 0 2 1 2 3 0 2 0 0 1 1 2 3 0 1 2 3 0 1 1 2 2 3 0 2 1 0 3 2 0 1 0 2 1 0 2 1 2 1 0 1 0 1 "
echo "and frames 3"
./memory 3 1 0 2 3 0 2 1 2 3 0 2 0 0 1 1 2 3 0 1 2 3 0 1 1 2 2 3 0 2 1 0 3 2 0 1 0 2 1 0 2 1 2 1 0 1 0 1 
echo "and frames 4"
./memory 4 1 0 2 3 0 2 1 2 3 0 2 0 0 1 1 2 3 0 1 2 3 0 1 1 2 2 3 0 2 1 0 3 2 0 1 0 2 1 0 2 1 2 1 0 1 0 1 
echo "and frames 5"
./memory 5 1 0 2 3 0 2 1 2 3 0 2 0 0 1 1 2 3 0 1 2 3 0 1 1 2 2 3 0 2 1 0 3 2 0 1 0 2 1 0 2 1 2 1 0 1 0 1 
echo "and frames 6"
./memory 6 1 0 2 3 0 2 1 2 3 0 2 0 0 1 1 2 3 0 1 2 3 0 1 1 2 2 3 0 2 1 0 3 2 0 1 0 2 1 0 2 1 2 1 0 1 0 1 