(Complied with gcc 9.3 & tested on Ubuntu 20.04)
1. Correct execution of the simple shell (10 marks)=> Done
2. Foreground and background processes (2 marks) => Not working
3. internal and external commands implemented (2marks) => Done
4. Exception handling (2marks) => Done
5. Mode of operation: batch and interactive (2marks) => Done
6. Pipe implementation (2marks) => Not working


cmd like exit, ls, pwd and cd work fine.